onmessage = function(e) {
	console.log('w2');
    postMessage({call2: ''});
};

//close();